/* 轮播图move函数 */
function move(obj , attr , target , speed , callback){
    clearInterval(obj.timer)
    /* 开启一个定时器，用来执行动画效果 */

    var current = parseInt(getStyle(obj,attr));
    if(current > target){
        speed = -speed
    }

    obj.timer = setInterval(function(){
        /* 获取原来的数值 */
        var oldValue = parseInt(getStyle(obj,attr));
        /* 在旧值基础上增加 */
        var newValue = oldValue + speed;

        if((speed < 0 && newValue < target)||(speed > 0 && newValue > target)){
            newValue = target;
        }

        /* 将新设置的值赋给obj */
        obj.style[attr] = newValue + "px";
        if(newValue == target){
            /* 关闭计时器 */
            clearInterval(obj.timer);
            callback && callback();
        }
    }, 30);
}

function getStyle(obj , name){
    if(window.getComputedStyle){
        return getComputedStyle(obj, null)[name];
    }else{
        return obj.currentStyle[name];
    }
}

/* 设置轮播图 */
window.onload = function(){
    /* 利用js函数定义ul宽度 */
     var imgList = document.getElementById("imgList");
     var imgArr = document.getElementsByClassName("m-img");
     imgList.style.width = 1540*imgArr.length+"px";

     /* 设置导航按钮居住 */
     var navDiv = document.getElementById("navDiv");
     var outer = document.getElementById("outer");
     navDiv.style.left = (outer.offsetWidth - navDiv.offsetWidth)/2+"px";
 
     /* 设置第一个图片默认 */
     var allA = document.getElementsByClassName("btn");
     var index = 0;
     allA[index].style.background = "white"

     /* 点击导航按钮切换图片 */
     for(var i=0;i<allA.length;i++){
         /* 为每个超链接加一个num属性 */
         allA[i].num = i;
         /* 为所有超链接绑定单机响应函数 */
         allA[i].onclick = function(){
             /* 关闭自动切换的定时器 */
             clearInterval(timer);
             /* 获取点击超链接的索引,并将其设置为index */
             index = this.num;
             /* 切换图片 */
             /* imgList.style.left = -1230*index+"px"; */  
             move(imgList , "left" , -1540*index , 60 , function(){
             /* 开启自动切换 */
             autoChange();
             });
             setA();           
         };
     }

     /* 开启自动切换轮播图 */
     autoChange();

     /* 设置选中的a的背景 */
     function setA(){
         /* 判断当前的索引是不是最后一张图片 */
         if(index >= imgArr.length-1){
             index=0;
             /* 通过css将最后一张直接改变成第一张 */
             imgList.style.left = 0;
         }

         for(var i=0;i<allA.length;i++){
             allA[i].style.background = "";/* 设置空，取消内联样式优先级，采用样式表样式,使hover生效 */
         }
         allA[index].style.background = "white";
     };
     
     /* 定义一个自动切换的定时器标识 */
     var timer;

     /* 创建一个函数，开启自动切换 */
     function autoChange(){
     /* 开启一个定时器，定时去切换 */
     timer = setInterval(function(){
     /* 使索引自增 */
     index++;
     /* 判断index的值 */
     index %=imgArr.length;
     /* 执行动画，切换图片 */
     move(imgList , "left" , -1540*index , 30 ,function(){
         /* 修改导航点 */
         setA();
     })

     },3000);
     }
}