function demo(){
    document.getElementById("siteWelcome").style.display = "none";
};

setTimeout("demo()",4000);
